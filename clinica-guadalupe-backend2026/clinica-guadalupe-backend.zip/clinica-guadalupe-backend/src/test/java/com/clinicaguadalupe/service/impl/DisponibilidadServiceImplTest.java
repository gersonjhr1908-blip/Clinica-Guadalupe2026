package com.clinicaguadalupe.service.impl;

import com.clinicaguadalupe.dto.DisponibilidadResponse;
import com.clinicaguadalupe.entity.Cita;
import com.clinicaguadalupe.entity.Consultorio;
import com.clinicaguadalupe.entity.DiaSemana;
import com.clinicaguadalupe.entity.EstadoCita;
import com.clinicaguadalupe.entity.HorarioMedico;
import com.clinicaguadalupe.entity.Medico;
import com.clinicaguadalupe.repository.CitaRepository;
import com.clinicaguadalupe.repository.HorarioMedicoRepository;
import com.clinicaguadalupe.repository.MedicoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DisponibilidadServiceImplTest {

    @Mock
    private MedicoRepository medicoRepository;

    @Mock
    private HorarioMedicoRepository horarioRepository;

    @Mock
    private CitaRepository citaRepository;

    @InjectMocks
    private DisponibilidadServiceImpl disponibilidadService;

    @Test
    void debeOcultarElHorarioOcupado() {

        // Se obtiene el próximo lunes para que la fecha siempre sea futura.
        LocalDate fecha = LocalDate.now()
                .with(
                        TemporalAdjusters.next(
                                DayOfWeek.MONDAY
                        )
                );

        // Médico con consultas de 30 minutos.
        Medico medico = new Medico();
        medico.setActivo(true);
        medico.setDuracionConsultaMinutos(30);

        // Consultorio donde atenderá el médico.
        Consultorio consultorio = new Consultorio();
        consultorio.setCodigo("CAR-101");
        consultorio.setNombre(
                "Consultorio de Cardiología"
        );

        // Horario del médico: lunes de 08:00 a 12:00.
        HorarioMedico horario = new HorarioMedico();
        horario.setMedico(medico);
        horario.setConsultorio(consultorio);
        horario.setDiaSemana(DiaSemana.LUNES);
        horario.setHoraInicio(LocalTime.of(8, 0));
        horario.setHoraFin(LocalTime.of(12, 0));
        horario.setActivo(true);

        // Cita que ocupa el turno de 09:00 a 09:30.
        Cita citaOcupada = new Cita();
        citaOcupada.setFechaHoraInicio(
                LocalDateTime.of(
                        fecha,
                        LocalTime.of(9, 0)
                )
        );
        citaOcupada.setFechaHoraFin(
                LocalDateTime.of(
                        fecha,
                        LocalTime.of(9, 30)
                )
        );
        citaOcupada.setEstado(EstadoCita.CONFIRMADA);

        // Configuración de los repositorios simulados.
        when(medicoRepository.findById(1L))
                .thenReturn(Optional.of(medico));

        when(
                horarioRepository
                        .findByMedicoIdAndDiaSemanaAndActivoTrueOrderByHoraInicioAsc(
                                1L,
                                DiaSemana.LUNES
                        )
        ).thenReturn(List.of(horario));

        when(
                citaRepository.buscarCitasActivasDelMedico(
                        eq(1L),
                        any(LocalDateTime.class),
                        any(LocalDateTime.class),
                        eq(EstadoCita.CANCELADA)
                )
        ).thenReturn(List.of(citaOcupada));

        // Se ejecuta el método que estamos probando.
        List<DisponibilidadResponse> resultado =
                disponibilidadService.obtenerDisponibilidad(
                        1L,
                        fecha
                );

        // De 8 turnos posibles queda 7 porque uno está ocupado.
        assertEquals(7, resultado.size());

        // El turno de las 08:00 debe estar disponible.
        assertTrue(
                resultado.stream().anyMatch(
                        turno ->
                                turno.horaInicio()
                                        .equals(LocalTime.of(8, 0))
                )
        );

        // El turno ocupado de las 09:00 no debe aparecer.
        assertFalse(
                resultado.stream().anyMatch(
                        turno ->
                                turno.horaInicio()
                                        .equals(LocalTime.of(9, 0))
                )
        );
    }
}